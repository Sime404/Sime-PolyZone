PolyZone = {}

PolyZone.DebugEnabled = false  -- se "true" Attiva il debug